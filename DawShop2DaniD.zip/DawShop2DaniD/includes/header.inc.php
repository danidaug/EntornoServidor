<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<header>
     <nav>
        <a href="index.html">
            <img src="img/daniware.png" alt="Logo" class="logo">
        </a>
        <ul>
            <li><a href="index.html">Presentación</a></li>
            <li><a href="catalogo.html">Catálogo</a></li>
            <li><a href="promociones.html">Promociones</a></li>
            <li><a href="donde.html">Dónde estamos</a></li> 
        </ul>
    </nav>
</header>
</html>