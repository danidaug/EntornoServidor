<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <link rel="stylesheet" href="styles/style.css">
</head>
<header>
<?php
    require_once($_SERVER['DOCUMENT_ROOT'].'/includes/header.inc.php')
?>
</header>
<body>
    <h1>Quienes somos???</h1>
    <p>Somos una tienda dedicada a la venta de productos cosmicos, estos consumibles te harán estar a otro nivel.</p>
    <p>Descubre nuestro <a href="catalogo.html"><strong>CATÁLOGO</strong></a> de productos cosmicos</p> 
    <div class="presentacion">
        <img src="img/daniware.png" alt="dani">
    </div>
     <footer>
        <?php
            require_once($_SERVER['DOCUMENT_ROOT'].'/includes/footer.inc.php')
        ?>
    </footer>
</body>

</html>